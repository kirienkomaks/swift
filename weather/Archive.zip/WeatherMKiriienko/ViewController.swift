//
//  ViewController.swift
//  WeatherMKiriienko
//
//  Created by Student on 30/05/2020.
//  Copyright © 2020 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var labelSity: UILabel!
    
    @IBOutlet weak var labelTemp: UILabel!
    
    @IBOutlet weak var labelWind: UILabel!
    
    @IBOutlet weak var weatherImage: UIImageView!
    
    @IBOutlet weak var labelType: UILabel!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var labelWindDir: UILabel!
    
    @IBOutlet weak var labelPrecip: UILabel!
    
    @IBOutlet weak var labelPressure: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        searchBar.delegate = self
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}
extension ViewController: UISearchBarDelegate{
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {

        let url = URL(string: "http://api.weatherstack.com/forecast?access_key=e496bd3c1cc0ed2a4ef8f6f2833d3184&query=\(searchBar.text!)")
        
        var locationName: String?
        var tempC: Double?
        var wind: Double?
        var windDir: String?
        var wImg: String?
        var image: UIImage?
        var date:String?
        var type:String?
        var precip:Double?
        var pressure:Double?
        
        let task = URLSession.shared.dataTask(with: url!){[weak self](data, response, error) in
            if let data = data{
                if let jsonString = String(data:data, encoding: .utf8){
                    print(jsonString)
                }
            }
            do{
                let json  = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String : AnyObject]
                if let location = json["location"]{
                    locationName = location["name"] as? String
                    date = location["localtime"] as? String
                }
                if let current = json["current"]{
                    tempC = current["temperature"] as? Double
                    wind = current["wind_speed"] as? Double
                    windDir = current["wind_dir"] as? String
                    precip = current["precip"] as? Double
                    pressure = current["pressure"] as? Double
                    let typeCurr = current["weather_descriptions"] as! [String]
                    type = typeCurr[0] as? String

                    let imgArray = current["weather_icons"] as! [String]
                    wImg = imgArray[0] as? String

                    let urlImage = URL(string:wImg!)
                    
                    let imgLoader = try URLSession.shared.dataTask(with: urlImage!){(data, response, error) in
                        if let imageData = data{
                            DispatchQueue.main.async {
                                self?.weatherImage.image = UIImage(data:imageData)
                                image=UIImage(data:imageData)

                            }
                        }
                    }
                    imgLoader.resume()
                    
//                    DispatchQueue.global().async {
//                        guard let imageData = try? Data(contentsOf: urlImage!) else {return}
//                        image = UIImage(data:imageData)
//                        DispatchQueue.main.async {
//                            self?.weatherImage.image = image
//                        }
//
//                    }
                }
            
                DispatchQueue.main.async {
                    self?.labelSity.text = locationName
                    self?.labelTemp.text = "\(tempC!)"
                    self?.labelWind.text = "\(wind!)"
                    self?.labelDate.text=date
                    self?.labelType.text=type
                    self?.labelWindDir.text = windDir
                    self?.labelPrecip.text = "\(precip!)"
                    self?.labelPressure.text = "\(pressure!)"
                }
            }
            catch let jsonError{
                print(jsonError)
            }
        }
        task.resume()
        
        
        
    }

}

