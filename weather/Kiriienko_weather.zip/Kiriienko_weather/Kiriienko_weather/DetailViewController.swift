//
//  DetailViewController.swift
//  Kiriienko_weather
//
//  Created by Student on 13/06/2020.
//  Copyright © 2020 Student. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var Sity: UILabel!
    
    @IBOutlet weak var date: UILabel!
    
    @IBOutlet weak var CurrentTemp: UILabel!
    @IBOutlet weak var MaxTemp: UILabel!
    @IBOutlet weak var MinTemp: UILabel!
    @IBOutlet weak var Wind: UILabel!
    @IBOutlet weak var Dir: UILabel!
    @IBOutlet weak var Pressure: UILabel!
    
    var pageNumber : Int = 0
    @IBOutlet weak var Next: UIButton!
    @IBOutlet weak var Prev: UIButton!
    
    var weatherData: [[String:Any]] = []


    @IBOutlet weak var weatherImage: UIImageView!
    
    var city : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let mainUrl = URL(string: "https://www.metaweather.com/api/location/search/?query=" + city!)!
        let task = URLSession.shared.dataTask(with: mainUrl) {(data, response, error) in
            let json = try? JSONSerialization.jsonObject(with: data!, options: []) as! [Any]
            let jsonMap = json![0] as! [String:Any]
            let woeid = String(jsonMap["woeid"] as! Int)
            let cityDataUrl = URL(string: "https://www.metaweather.com/api/location/" + woeid)!
            
            let loadLocation = URLSession.shared.dataTask(with: cityDataUrl) {(data, response, error) in
                guard let data = data else { return }

                let jsonLoc = try? JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                let jsonData = jsonLoc! as! [String:Any]
                let dataloc = jsonData["consolidated_weather"]! as! [Any]
                DispatchQueue.main.async {
                    self.Prev.isEnabled = false
                    self.weatherData = dataloc as! [[String:Any]]
                    self.display(0)
                }
            }.resume()
        }.resume()
        
    }
    
    func display(_ index: Int) {
        if(index < self.weatherData.count && index >= 0) {
            let data = self.weatherData[index]
            self.Sity.text = city
            self.date.text = (data["applicable_date"] as! String)
            self.Pressure.text = String(data["air_pressure"] as! Double)
            self.MaxTemp.text = String(data["max_temp"] as! Double)
            self.MinTemp.text = String(data["min_temp"] as! Double)
            self.CurrentTemp.text = String(data["the_temp"] as! Double)
            self.Dir.text = (data["wind_direction_compass"] as! String)
            self.Wind.text = String(format: "%.4f", data["wind_speed"] as! Double)
            
            let url = URL(string: "https://www.metaweather.com/static/img/weather/png/" +  (data["weather_state_abbr"] as! String) + ".png")
            
            let task2 = URLSession.shared.dataTask(with: url!, completionHandler: {data, response, error in DispatchQueue.main.async {
                guard let data = data else {return}
                
                self.weatherImage.image = UIImage(data: data)
                }}).resume()
            
        }
    }
    
    
    @IBAction func nextPage(_ sender: UIButton) {
        self.pageNumber = self.pageNumber + 1
        
        if self.pageNumber == self.weatherData.count {
            self.Next.isEnabled = false
        }
        
        self.Prev.isEnabled = true
        self.display(self.pageNumber)
    }
    
    @IBAction func prevPage(_ sender: UIButton) {
        self.pageNumber = self.pageNumber - 1
        
        if self.pageNumber == 0 {
            self.Prev.isEnabled = false
        }
        
        self.Next.isEnabled = true
        self.display(self.pageNumber)
    }
    

    

}
